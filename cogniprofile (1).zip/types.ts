export interface LifePhase {
  phase: string;
  description: string;
  yearRange?: string;
}

export interface BasicOverview {
  fullName: string;
  fieldOfInfluence: string;
  era: string;
  wellKnownFor: string;
  birthPlace?: string;
  nationality?: string;
}

export interface MajorWork {
  title: string;
  year?: string;
  description: string;
}

export interface ControversyEvent {
  title: string;
  description: string;
  outcome: string;
}

export interface ProfileData {
  basicOverview: BasicOverview;
  coreBeliefs: string[];
  supported: string[];
  opposed: string[];
  keyQuestions: string[];
  lifeCategorization: LifePhase[];
  
  // Detailed Negative/Critical Analysis
  controversialBeliefs: string[];
  criticisms: string[];
  majorControversies: ControversyEvent[];

  impact: string;
  quotes: string[];
  majorWorks: MajorWork[];
  influence: {
    influencedBy: string[];
    influenced: string[];
  };
}

export interface SearchState {
  query: string;
  isLoading: boolean;
  data: ProfileData | null;
  error: string | null;
}