import React from 'react';
import { ProfileData } from '../types';
import { 
  User, 
  Clock, 
  Briefcase, 
  ThumbsUp, 
  ThumbsDown, 
  HelpCircle, 
  GitCommit, 
  AlertTriangle, 
  TrendingUp,
  Quote,
  BookOpen,
  Share2,
  MapPin,
  Flag,
  Scale,
  AlertOctagon
} from 'lucide-react';

interface ProfileViewProps {
  data: ProfileData;
}

const SectionTitle: React.FC<{ icon: React.ReactNode; title: string; className?: string }> = ({ icon, title, className = "" }) => (
  <h3 className={`flex items-center gap-2 text-xl font-serif font-bold text-slate-800 dark:text-slate-100 mb-4 ${className}`}>
    <span className="text-blue-600 dark:text-blue-400">{icon}</span>
    {title}
  </h3>
);

const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = "" }) => (
  <div className={`bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 p-6 transition-colors ${className}`}>
    {children}
  </div>
);

const ListItems: React.FC<{ items: string[]; type?: 'neutral' | 'check' | 'cross' | 'warning' }> = ({ items, type = 'neutral' }) => (
  <ul className="space-y-3">
    {items.map((item, idx) => (
      <li key={idx} className="flex items-start gap-3">
        <span className={`mt-1.5 min-w-[8px] min-h-[8px] rounded-full flex-shrink-0 ${
          type === 'check' ? 'bg-green-500' : 
          type === 'cross' ? 'bg-red-500' : 
          type === 'warning' ? 'bg-amber-500' :
          'bg-slate-400 dark:bg-slate-500'
        }`} />
        <span className="text-slate-700 dark:text-slate-300 leading-relaxed">{item}</span>
      </li>
    ))}
  </ul>
);

const Tag: React.FC<{ text: string }> = ({ text }) => (
  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
    {text}
  </span>
);

export const ProfileView: React.FC<ProfileViewProps> = ({ data }) => {
  const { 
    basicOverview, 
    coreBeliefs, 
    supported, 
    opposed, 
    keyQuestions, 
    lifeCategorization, 
    controversialBeliefs,
    criticisms,
    majorControversies,
    impact,
    quotes,
    majorWorks,
    influence
  } = data;

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in pb-20">
      
      {/* Header Section */}
      <header className="relative bg-white dark:bg-slate-900 rounded-2xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Share2 size={120} className="text-slate-900 dark:text-white" />
        </div>
        
        <div className="relative z-10 text-center md:text-left">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 text-xs font-semibold tracking-wider uppercase rounded-full">
                <Briefcase size={12} />
                {basicOverview.fieldOfInfluence}
              </div>
              
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white">
                {basicOverview.fullName}
              </h1>
              
              <div className="flex flex-wrap justify-center md:justify-start gap-4 md:gap-6 text-slate-500 dark:text-slate-400 text-sm">
                <span className="flex items-center gap-1.5"><Clock size={16} /> {basicOverview.era}</span>
                {basicOverview.nationality && (
                  <span className="flex items-center gap-1.5"><Flag size={16} /> {basicOverview.nationality}</span>
                )}
                {basicOverview.birthPlace && (
                  <span className="flex items-center gap-1.5"><MapPin size={16} /> {basicOverview.birthPlace}</span>
                )}
              </div>
            </div>
          </div>

          <div className="mt-8 p-6 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700/50">
            <p className="text-xl md:text-2xl text-slate-700 dark:text-slate-300 italic font-serif text-center">
              "{basicOverview.wellKnownFor}"
            </p>
          </div>
        </div>
      </header>

      {/* Quotes Section */}
      {quotes && quotes.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {quotes.map((quote, idx) => (
            <div key={idx} className="bg-blue-600 text-white p-6 rounded-xl relative overflow-hidden shadow-md">
              <Quote className="absolute top-4 right-4 text-blue-400 opacity-50" size={40} />
              <p className="relative z-10 font-serif italic text-lg leading-relaxed">
                "{quote}"
              </p>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Beliefs & Stance */}
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             {/* Core Beliefs */}
            <Card className="h-full">
              <SectionTitle icon={<User size={20} />} title="Core Beliefs" />
              <ListItems items={coreBeliefs} />
            </Card>

            {/* Key Questions */}
            <Card className="h-full bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700">
              <SectionTitle icon={<HelpCircle size={20} />} title="Key Questions" />
              <div className="space-y-4">
                {keyQuestions.map((q, idx) => (
                  <div key={idx} className="flex gap-3">
                    <span className="text-blue-500 dark:text-blue-400 font-serif font-bold text-lg">?</span>
                    <p className="text-slate-700 dark:text-slate-300 font-medium">{q}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

           {/* Supported vs Opposed */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-l-4 border-l-green-500">
              <SectionTitle icon={<ThumbsUp size={20} />} title="Strongly Supported" className="text-green-800 dark:text-green-400" />
              <ListItems items={supported} type="check" />
            </Card>

            <Card className="border-l-4 border-l-red-500">
              <SectionTitle icon={<ThumbsDown size={20} />} title="Opposed / Rejected" className="text-red-800 dark:text-red-400" />
              <ListItems items={opposed} type="cross" />
            </Card>
          </div>
        </div>

        {/* Right Column: Works & Network */}
        <div className="space-y-6">
          {/* Major Works */}
          {majorWorks && majorWorks.length > 0 && (
            <Card>
              <SectionTitle icon={<BookOpen size={20} />} title="Major Works" />
              <div className="space-y-5">
                {majorWorks.map((work, idx) => (
                  <div key={idx} className="group">
                    <div className="flex items-baseline justify-between mb-1">
                      <h4 className="font-bold text-slate-800 dark:text-slate-200">{work.title}</h4>
                      {work.year && <span className="text-xs text-slate-400 dark:text-slate-500 font-mono">{work.year}</span>}
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-400 leading-snug">{work.description}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Influence Network */}
          <Card className="bg-slate-50 dark:bg-slate-800/50">
            <SectionTitle icon={<Share2 size={20} />} title="Network" />
            
            <div className="mb-6">
              <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">Influenced By</h4>
              <div className="flex flex-wrap gap-2">
                {influence.influencedBy.map((person, i) => (
                  <Tag key={i} text={person} />
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">Influenced</h4>
              <div className="flex flex-wrap gap-2">
                {influence.influenced.map((person, i) => (
                  <Tag key={i} text={person} />
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* CRITICAL ANALYSIS SECTION (NEW) */}
      <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 rounded-2xl p-6 md:p-8">
        <div className="flex items-center gap-3 mb-6">
          <AlertOctagon className="text-amber-600 dark:text-amber-500" size={28} />
          <h2 className="text-2xl font-serif font-bold text-slate-900 dark:text-amber-100">Critical Analysis & Controversies</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Controversial Beliefs & Criticisms */}
          <div className="space-y-6">
            {controversialBeliefs.length > 0 && (
              <div>
                 <h4 className="text-sm font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-3 flex items-center gap-2">
                   <Scale size={16} /> Controversial Beliefs
                 </h4>
                 <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-amber-100 dark:border-amber-900/30">
                    <ListItems items={controversialBeliefs} type="warning" />
                 </div>
              </div>
            )}
            
            {criticisms.length > 0 && (
              <div>
                 <h4 className="text-sm font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-3 flex items-center gap-2">
                   <AlertTriangle size={16} /> Common Criticisms
                 </h4>
                 <div className="bg-white dark:bg-slate-900 rounded-xl p-5 border border-amber-100 dark:border-amber-900/30">
                    <ListItems items={criticisms} type="warning" />
                 </div>
              </div>
            )}
          </div>

          {/* Specific Major Controversies */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-amber-800 dark:text-amber-400 mb-3">Major Controversies & Scandals</h4>
            {majorControversies.length > 0 ? (
              majorControversies.map((c, idx) => (
                <div key={idx} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-amber-100 dark:border-amber-900/30 shadow-sm">
                  <h5 className="font-bold text-slate-900 dark:text-amber-100 text-lg mb-2">{c.title}</h5>
                  <p className="text-slate-700 dark:text-slate-300 text-sm leading-relaxed mb-3">{c.description}</p>
                  <div className="text-xs bg-amber-100 dark:bg-amber-900/40 text-amber-900 dark:text-amber-200 px-3 py-2 rounded-lg font-medium">
                    <span className="font-bold opacity-70 uppercase mr-1">Outcome:</span> {c.outcome}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-slate-500 italic">No specific major controversies recorded.</p>
            )}
          </div>
        </div>
      </div>

      {/* Life Categorization Timeline */}
      <Card>
        <SectionTitle icon={<GitCommit size={20} />} title="Timeline & Life Phases" />
        <div className="relative pl-8 border-l-2 border-slate-100 dark:border-slate-800 space-y-8 my-4">
          {lifeCategorization.map((phase, idx) => (
            <div key={idx} className="relative">
              <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full border-4 border-white dark:border-slate-900 bg-blue-500 shadow-sm" />
              <div>
                <h4 className="text-lg font-bold text-slate-800 dark:text-slate-200">{phase.phase}</h4>
                {phase.yearRange && (
                  <span className="text-xs text-slate-400 dark:text-slate-500 font-mono mb-1 block">{phase.yearRange}</span>
                )}
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{phase.description}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Impact Footer */}
      <Card className="bg-gradient-to-br from-blue-50 to-white dark:from-slate-800 dark:to-slate-900 border-blue-100 dark:border-slate-700">
        <SectionTitle icon={<TrendingUp size={20} className="text-blue-600 dark:text-blue-400" />} title="Impact & Legacy" />
        <p className="text-slate-800 dark:text-slate-200 text-lg font-serif leading-relaxed">
          {impact}
        </p>
      </Card>

    </div>
  );
};