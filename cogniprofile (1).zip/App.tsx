import React, { useState, useEffect } from 'react';
import { Search, Loader2, Sparkles, AlertCircle, Moon, Sun } from 'lucide-react';
import { generateProfile } from './services/geminiService';
import { ProfileView } from './components/ProfileView';
import { SearchState } from './types';

const INITIAL_SUGGESTIONS = [
  "Marie Curie",
  "Nelson Mandela",
  "Leonardo da Vinci",
  "Ada Lovelace",
  "Socrates"
];

const App: React.FC = () => {
  const [state, setState] = useState<SearchState>({
    query: '',
    isLoading: false,
    data: null,
    error: null,
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    // Check local storage or system preference on initial load
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    // Apply dark mode class to html element
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [darkMode]);

  const toggleTheme = () => setDarkMode(!darkMode);

  const handleSearch = async (term: string) => {
    if (!term.trim()) return;

    setState(prev => ({ ...prev, isLoading: true, error: null, query: term }));

    try {
      const data = await generateProfile(term);
      setState(prev => ({ ...prev, isLoading: false, data }));
    } catch (err) {
      setState(prev => ({ 
        ...prev, 
        isLoading: false, 
        error: "Failed to analyze profile. Please check the name or try again later." 
      }));
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(state.query);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-blue-100 dark:selection:bg-blue-900 transition-colors duration-300">
      
      {/* Navigation Bar */}
      <nav className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors duration-300">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-blue-600/20">
              <Sparkles size={18} />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">CogniProfile</span>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="hidden md:block text-xs text-slate-500 dark:text-slate-400 font-medium px-3 py-1 bg-slate-100 dark:bg-slate-800 rounded-full border border-slate-200 dark:border-slate-700">
              Powered by Gemini 3 Flash
            </div>
            <button 
              onClick={toggleTheme} 
              className="p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-8 md:py-12">
        
        {/* Search Hero Section - Collapses when data is present */}
        <div className={`transition-all duration-500 ease-in-out ${state.data ? 'mb-8' : 'min-h-[60vh] flex flex-col justify-center items-center mb-0'}`}>
          
          {!state.data && (
            <div className="text-center mb-8 space-y-4 animate-fade-in">
              <h1 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 dark:text-white tracking-tight">
                Decode a Legacy
              </h1>
              <p className="text-lg text-slate-500 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
                Generate highly detailed, structured, and neutral profiles of historical and famous figures using advanced AI analysis.
              </p>
            </div>
          )}

          <div className={`w-full max-w-2xl relative ${state.data ? '' : 'mx-auto'}`}>
            <form onSubmit={handleFormSubmit} className="relative group">
              <input
                type="text"
                value={state.query}
                onChange={(e) => setState(prev => ({ ...prev, query: e.target.value }))}
                placeholder="Enter a name (e.g., Albert Einstein)"
                className="w-full h-14 pl-12 pr-32 rounded-2xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-sm text-lg text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-blue-500 dark:focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 transition-all"
                disabled={state.isLoading}
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 group-focus-within:text-blue-500 transition-colors" size={24} />
              
              <button 
                type="submit"
                disabled={state.isLoading || !state.query.trim()}
                className="absolute right-2 top-2 h-10 px-6 bg-slate-900 dark:bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-600 dark:hover:bg-blue-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-md"
              >
                {state.isLoading ? <Loader2 size={18} className="animate-spin" /> : 'Analyze'}
              </button>
            </form>

            {/* Suggestions */}
            {!state.data && !state.isLoading && (
              <div className="mt-6 flex flex-wrap justify-center gap-2 text-sm">
                <span className="text-slate-400 dark:text-slate-500 py-1">Try:</span>
                {INITIAL_SUGGESTIONS.map(name => (
                  <button
                    key={name}
                    onClick={() => handleSearch(name)}
                    className="px-3 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full text-slate-600 dark:text-slate-400 hover:border-blue-400 dark:hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 transition-all"
                  >
                    {name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Error State */}
        {state.error && (
          <div className="max-w-2xl mx-auto mt-8 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/50 rounded-xl flex items-center gap-3 text-red-700 dark:text-red-300 animate-fade-in">
            <AlertCircle size={20} />
            <p>{state.error}</p>
          </div>
        )}

        {/* Loading Skeleton */}
        {state.isLoading && !state.data && (
          <div className="max-w-5xl mx-auto mt-12 space-y-8 animate-pulse">
            <div className="h-8 w-32 bg-slate-200 dark:bg-slate-800 rounded mx-auto mb-4"></div>
            <div className="h-12 w-3/4 bg-slate-200 dark:bg-slate-800 rounded mx-auto mb-4"></div>
            <div className="h-4 w-1/2 bg-slate-200 dark:bg-slate-800 rounded mx-auto mb-12"></div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl"></div>
              <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl"></div>
            </div>
            <div className="h-48 bg-slate-200 dark:bg-slate-800 rounded-xl"></div>
          </div>
        )}

        {/* Results View */}
        {state.data && !state.isLoading && (
          <ProfileView data={state.data} />
        )}

      </main>
    </div>
  );
};

export default App;