import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ProfileData } from "../types";

const apiKey = process.env.API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey });

const profileSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    basicOverview: {
      type: Type.OBJECT,
      properties: {
        fullName: { type: Type.STRING },
        fieldOfInfluence: { type: Type.STRING },
        era: { type: Type.STRING },
        wellKnownFor: { type: Type.STRING },
        birthPlace: { type: Type.STRING },
        nationality: { type: Type.STRING },
      },
      required: ["fullName", "fieldOfInfluence", "era", "wellKnownFor"],
    },
    coreBeliefs: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of core philosophical, political, or scientific beliefs.",
    },
    supported: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Policies, ideologies, methods, or lifestyles they strongly favored.",
    },
    opposed: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Ideas, systems, or practices they publicly criticized or rejected.",
    },
    keyQuestions: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Major questions they tried to answer or problems they aimed to solve.",
    },
    lifeCategorization: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          phase: { type: Type.STRING, description: "Name of the life phase (e.g., Early Life, Struggle, Peak)" },
          description: { type: Type.STRING, description: "Brief description of this phase." },
          yearRange: { type: Type.STRING, description: "Approximate years for this phase." },
        },
        required: ["phase", "description"],
      },
    },
    // New Detailed Critical Section
    controversialBeliefs: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Specific beliefs or opinions held by the person that were considered radical, offensive, or highly controversial during their time or in retrospect.",
    },
    criticisms: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Common arguments or criticisms made against their character, work, or methods by contemporaries or historians.",
    },
    majorControversies: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "Title of the specific scandal, conflict, or controversy." },
          description: { type: Type.STRING, description: "Detailed factual explanation of what happened." },
          outcome: { type: Type.STRING, description: "The result, aftermath, or how it affected their legacy." },
        },
        required: ["title", "description", "outcome"],
      },
      description: "Specific historical events, legal issues, or public scandals they were involved in.",
    },
    // End Critical Section
    impact: {
      type: Type.STRING,
      description: "Long-term influence on society and how people view them today.",
    },
    quotes: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "3-5 famous and representative quotes by this person.",
    },
    majorWorks: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          year: { type: Type.STRING },
          description: { type: Type.STRING },
        },
        required: ["title", "description"],
      },
      description: "Key books, inventions, laws, or artworks produced.",
    },
    influence: {
      type: Type.OBJECT,
      properties: {
        influencedBy: { type: Type.ARRAY, items: { type: Type.STRING }, description: "People or schools of thought that influenced them." },
        influenced: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Famous people or movements they influenced." },
      },
      required: ["influencedBy", "influenced"],
    },
  },
  required: [
    "basicOverview",
    "coreBeliefs",
    "supported",
    "opposed",
    "keyQuestions",
    "lifeCategorization",
    "controversialBeliefs",
    "criticisms",
    "majorControversies",
    "impact",
    "quotes",
    "majorWorks",
    "influence"
  ],
};

export const generateProfile = async (name: string): Promise<ProfileData> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a highly detailed, structured, factual, and neutral profile for: "${name}". 
      Focus on publicly available information. 
      
      CRITICAL INSTRUCTION: You must provide a comprehensive "Critical Analysis" section. 
      Do not hide negative aspects. Explicitly detail:
      1. Controversial Beliefs: Ideas they held that were problematic or debated.
      2. Criticisms: General arguments against them.
      3. Major Controversies: Specific events, scandals, or conflicts.
      
      Ensure the tone remains objective and factual (e.g., "Critics argue that..." or "He was accused of...") rather than judgmental.
      
      Include famous quotes, major works, and their network of influence.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: profileSchema,
        systemInstruction: "You are an intelligent analysis engine. Your goal is to provide deep, structured insights into famous individuals, including a thorough examination of their controversies and flaws.",
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response generated from Gemini.");
    }

    return JSON.parse(text) as ProfileData;
  } catch (error) {
    console.error("Error generating profile:", error);
    throw error;
  }
};