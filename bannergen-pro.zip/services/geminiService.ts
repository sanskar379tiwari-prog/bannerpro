import { GoogleGenAI, Type } from "@google/genai";
import { AdData, AspectRatio, ImageResolution } from "../types";

// Helper to get fresh AI instance with current key
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateAdCopy = async (data: AdData) => {
  const ai = getAI();
  
  const prompt = `
    Create catchy, professional banner ad copy for the following product:
    Product Name: ${data.productName}
    Description: ${data.description}
    Target Audience: ${data.targetAudience || 'General'}
    URL: ${data.url}

    Return a JSON object with:
    - headline (max 8 words, catchy)
    - subtext (max 15 words, value proposition)
    - cta (Call to Action button text, max 3 words)
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING },
            subtext: { type: Type.STRING },
            cta: { type: Type.STRING },
          },
          required: ['headline', 'subtext', 'cta'],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No text returned from model");
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating ad copy:", error);
    throw error;
  }
};

export const generateAdImage = async (
  data: AdData,
  ratio: AspectRatio,
  resolution: ImageResolution
) => {
  const ai = getAI();

  const prompt = `
    High-quality, commercial product photography background for a banner ad.
    Product Context: ${data.productName} - ${data.description}.
    Style: Professional, clean, high-end advertising aesthetic.
    Lighting: Studio lighting, soft shadows.
    Composition: Leave some negative space for text overlay.
    Do not include text in the image itself.
  `;

  try {
    // Using gemini-3-pro-image-preview as requested
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: ratio,
          imageSize: resolution,
        },
      },
    });

    // Iterate to find the image part
    for (const candidate of response.candidates || []) {
        for (const part of candidate.content.parts) {
            if (part.inlineData) {
                return `data:image/png;base64,${part.inlineData.data}`;
            }
        }
    }
    
    throw new Error("No image generated.");

  } catch (error) {
    console.error("Error generating ad image:", error);
    throw error;
  }
};
