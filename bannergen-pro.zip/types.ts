export type AspectRatio = '1:1' | '2:3' | '3:2' | '3:4' | '4:3' | '9:16' | '16:9' | '21:9';
export type ImageResolution = '1K' | '2K' | '4K';

export interface AdData {
  productName: string;
  description: string;
  url: string;
  targetAudience?: string;
}

export interface GeneratedAd {
  imageUrl: string;
  headline: string;
  subtext: string;
  cta: string;
}

export interface GenerationConfig {
  ratio: AspectRatio;
  resolution: ImageResolution;
}
