import React, { useState, useEffect } from 'react';
import { Key } from 'lucide-react';

interface ApiKeyGuardProps {
  children: React.ReactNode;
}

export const ApiKeyGuard: React.FC<ApiKeyGuardProps> = ({ children }) => {
  const [hasKey, setHasKey] = useState<boolean>(false);
  const [checking, setChecking] = useState<boolean>(true);

  const checkKey = async () => {
    try {
      const has = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(has);
    } catch (e) {
      console.error("Error checking API key status", e);
      setHasKey(false);
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    checkKey();
  }, []);

  const handleSelectKey = async () => {
    try {
      await (window as any).aistudio.openSelectKey();
      // Assume success as per guidelines, but re-check to be safe in state
      setHasKey(true); 
    } catch (e) {
      console.error("Error selecting key", e);
      // If error contains "Requested entity was not found", reset and try again
      const errString = String(e);
      if (errString.includes("Requested entity was not found")) {
        alert("Session expired or invalid. Please try selecting the key again.");
        setHasKey(false);
      }
    }
  };

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!hasKey) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center space-y-6">
            <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto text-indigo-600">
                <Key size={32} />
            </div>
            <div>
                <h1 className="text-2xl font-bold text-slate-900 mb-2">API Key Required</h1>
                <p className="text-slate-600">
                    To generate high-quality images with <strong>Gemini 3 Pro</strong>, you need to connect your Google Cloud project with a paid billing account.
                </p>
            </div>
            
            <button 
                onClick={handleSelectKey}
                className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl transition-colors shadow-md flex items-center justify-center gap-2"
            >
                Select API Key
            </button>

            <div className="text-xs text-slate-400 mt-4">
                <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="underline hover:text-indigo-500">
                    Read billing documentation
                </a>
            </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};