import React from 'react';
import { GeneratedAd, AspectRatio } from '../types';

interface AdPreviewProps {
  ad: GeneratedAd | null;
  ratio: AspectRatio;
  loading: boolean;
}

const getAspectRatioClass = (ratio: AspectRatio): string => {
  switch (ratio) {
    case '1:1': return 'aspect-square';
    case '2:3': return 'aspect-[2/3]';
    case '3:2': return 'aspect-[3/2]';
    case '3:4': return 'aspect-[3/4]';
    case '4:3': return 'aspect-[4/3]';
    case '9:16': return 'aspect-[9/16]';
    case '16:9': return 'aspect-video';
    case '21:9': return 'aspect-[21/9]';
    default: return 'aspect-video';
  }
};

export const AdPreview: React.FC<AdPreviewProps> = ({ ad, ratio, loading }) => {
  if (loading) {
    return (
      <div className={`w-full h-full min-h-[400px] flex items-center justify-center bg-slate-100 rounded-xl border-2 border-dashed border-slate-300 animate-pulse`}>
        <div className="text-center space-y-3">
            <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-slate-500 font-medium">Designing your ad...</p>
            <p className="text-xs text-slate-400">Generating high-res image & copy</p>
        </div>
      </div>
    );
  }

  if (!ad) {
    return (
      <div className="w-full h-full min-h-[400px] flex items-center justify-center bg-slate-100 rounded-xl border-2 border-dashed border-slate-300">
        <div className="text-center text-slate-400">
          <p>Fill out the form and click generate</p>
          <p className="text-sm">Your preview will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-slate-900 rounded-xl overflow-auto custom-scrollbar">
       <div className={`relative w-full max-w-4xl shadow-2xl rounded-lg overflow-hidden group ${getAspectRatioClass(ratio)}`}>
          {/* Background Image */}
          <img 
            src={ad.imageUrl} 
            alt="Generated Ad Background" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          
          {/* Overlay Gradient for readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent"></div>

          {/* Text Content Overlay */}
          <div className="absolute inset-0 p-8 flex flex-col justify-center items-start text-white max-w-[70%]">
            <h2 className="text-3xl md:text-5xl font-bold leading-tight mb-4 drop-shadow-lg">
              {ad.headline}
            </h2>
            <p className="text-lg md:text-xl text-slate-100 mb-8 drop-shadow-md font-medium">
              {ad.subtext}
            </p>
            <button className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition-transform transform hover:scale-105 active:scale-95 flex items-center gap-2">
              {ad.cta}
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
            </button>
          </div>
       </div>
    </div>
  );
};
