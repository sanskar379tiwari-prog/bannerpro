import React from 'react';
import { AdData, AspectRatio, ImageResolution } from '../types';
import { ASPECT_RATIOS, RESOLUTIONS } from '../constants';
import { Wand2, Layout, Image as ImageIcon } from 'lucide-react';

interface AdFormProps {
  data: AdData;
  onChange: (data: AdData) => void;
  ratio: AspectRatio;
  setRatio: (r: AspectRatio) => void;
  resolution: ImageResolution;
  setResolution: (r: ImageResolution) => void;
  onGenerate: () => void;
  loading: boolean;
}

export const AdForm: React.FC<AdFormProps> = ({
  data,
  onChange,
  ratio,
  setRatio,
  resolution,
  setResolution,
  onGenerate,
  loading
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    onChange({ ...data, [e.target.name]: e.target.value });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900 mb-1">Ad Details</h2>
        <p className="text-sm text-slate-500 mb-4">Describe your product to generate the perfect banner.</p>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Product Name</label>
            <input
              type="text"
              name="productName"
              value={data.productName}
              onChange={handleChange}
              placeholder="e.g. NeoRun Sneakers"
              className="w-full px-4 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Product URL</label>
            <input
              type="url"
              name="url"
              value={data.url}
              onChange={handleChange}
              placeholder="https://example.com/product"
              className="w-full px-4 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
            <textarea
              name="description"
              value={data.description}
              onChange={handleChange}
              rows={3}
              placeholder="Lightweight running shoes with reactive foam technology..."
              className="w-full px-4 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Target Audience (Optional)</label>
            <input
              type="text"
              name="targetAudience"
              value={data.targetAudience}
              onChange={handleChange}
              placeholder="e.g. Marathon runners, fitness enthusiasts"
              className="w-full px-4 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-200">
        <h2 className="text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <Layout size={20} />
            Format & Quality
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Aspect Ratio</label>
                <div className="grid grid-cols-4 gap-2">
                    {ASPECT_RATIOS.map((ar) => (
                        <button
                            key={ar.value}
                            onClick={() => setRatio(ar.value)}
                            className={`p-2 flex flex-col items-center justify-center gap-1 rounded-lg border text-xs font-medium transition-all ${
                                ratio === ar.value
                                ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                                : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'
                            }`}
                            title={ar.label}
                        >
                            <ar.icon size={16} />
                            {ar.value}
                        </button>
                    ))}
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Image Resolution</label>
                <div className="flex gap-2">
                    {RESOLUTIONS.map((res) => (
                        <button
                            key={res.value}
                            onClick={() => setResolution(res.value)}
                            className={`flex-1 py-2 px-3 rounded-lg border text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                                resolution === res.value
                                ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                                : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'
                            }`}
                        >
                            <ImageIcon size={14} />
                            {res.value}
                        </button>
                    ))}
                </div>
                <p className="mt-2 text-xs text-slate-400">
                    Using <strong>gemini-3-pro-image-preview</strong> for high-fidelity rendering.
                </p>
            </div>
        </div>
      </div>

      <button
        onClick={onGenerate}
        disabled={loading || !data.productName || !data.description}
        className={`w-full py-4 mt-4 rounded-xl font-bold text-white shadow-lg flex items-center justify-center gap-2 transition-all ${
            loading || !data.productName || !data.description
            ? 'bg-slate-300 cursor-not-allowed'
            : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 transform hover:-translate-y-0.5'
        }`}
      >
        {loading ? (
            <>Generating...</>
        ) : (
            <>
                <Wand2 size={20} />
                Generate Banner Ad
            </>
        )}
      </button>
    </div>
  );
};
