import { AspectRatio, ImageResolution } from './types';
import { Square, RectangleVertical, RectangleHorizontal, Smartphone, Monitor } from 'lucide-react';

export const ASPECT_RATIOS: { value: AspectRatio; label: string; icon: any }[] = [
  { value: '1:1', label: 'Square (1:1)', icon: Square },
  { value: '2:3', label: 'Portrait (2:3)', icon: RectangleVertical },
  { value: '3:2', label: 'Landscape (3:2)', icon: RectangleHorizontal },
  { value: '3:4', label: 'Classic Portrait (3:4)', icon: RectangleVertical },
  { value: '4:3', label: 'Classic Landscape (4:3)', icon: RectangleHorizontal },
  { value: '9:16', label: 'Social Story (9:16)', icon: Smartphone },
  { value: '16:9', label: 'Widescreen (16:9)', icon: Monitor },
  { value: '21:9', label: 'Ultrawide (21:9)', icon: Monitor },
];

export const RESOLUTIONS: { value: ImageResolution; label: string }[] = [
  { value: '1K', label: 'Standard (1K)' },
  { value: '2K', label: 'High Res (2K)' },
  { value: '4K', label: 'Ultra Res (4K)' },
];
