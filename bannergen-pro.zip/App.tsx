import React, { useState } from 'react';
import { ApiKeyGuard } from './components/ApiKeyGuard';
import { AdForm } from './components/AdForm';
import { AdPreview } from './components/AdPreview';
import { AdData, GeneratedAd, AspectRatio, ImageResolution } from './types';
import { generateAdCopy, generateAdImage } from './services/geminiService';
import { Sparkles } from 'lucide-react';

const AppContent: React.FC = () => {
  const [formData, setFormData] = useState<AdData>({
    productName: '',
    description: '',
    url: '',
    targetAudience: ''
  });
  
  const [ratio, setRatio] = useState<AspectRatio>('16:9');
  const [resolution, setResolution] = useState<ImageResolution>('2K');
  const [loading, setLoading] = useState(false);
  const [generatedAd, setGeneratedAd] = useState<GeneratedAd | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setGeneratedAd(null);
    try {
      // Run generation in parallel
      const [copy, imageUrl] = await Promise.all([
        generateAdCopy(formData),
        generateAdImage(formData, ratio, resolution)
      ]);

      setGeneratedAd({
        imageUrl,
        headline: copy.headline,
        subtext: copy.subtext,
        cta: copy.cta
      });
    } catch (error) {
      console.error("Generation failed", error);
      alert("Failed to generate banner. Please check your inputs and try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-2 rounded-lg text-white">
            <Sparkles size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 leading-none">BannerGen Pro</h1>
            <p className="text-xs text-slate-500 mt-1">Powered by Gemini Nano Banana Pro</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden flex flex-col md:flex-row">
        {/* Left Panel: Controls */}
        <div className="w-full md:w-[450px] bg-white border-r border-slate-200 flex flex-col overflow-y-auto z-10 shadow-xl md:shadow-none">
          <div className="p-6">
            <AdForm 
              data={formData}
              onChange={setFormData}
              ratio={ratio}
              setRatio={setRatio}
              resolution={resolution}
              setResolution={setResolution}
              onGenerate={handleGenerate}
              loading={loading}
            />
          </div>
        </div>

        {/* Right Panel: Preview */}
        <div className="flex-1 bg-slate-100 relative overflow-hidden flex flex-col">
            {/* Toolbar Area (optional future expansion) */}
            <div className="h-12 border-b border-slate-200 bg-white/50 backdrop-blur flex items-center px-4 justify-end">
                <span className="text-xs font-mono text-slate-400">
                    Preview Mode: {resolution} • {ratio}
                </span>
            </div>
            
            {/* Canvas Area */}
            <div className="flex-1 p-8 overflow-auto flex items-center justify-center">
                <AdPreview 
                    ad={generatedAd}
                    ratio={ratio}
                    loading={loading}
                />
            </div>
        </div>
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ApiKeyGuard>
      <AppContent />
    </ApiKeyGuard>
  );
};

export default App;
